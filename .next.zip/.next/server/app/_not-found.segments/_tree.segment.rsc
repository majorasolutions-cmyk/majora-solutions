:HL["/_next/static/chunks/0f7x_ow_.n9s2.css","style"]
:HL["/_next/static/chunks/0jr9y50fk9xlf.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"U3OT2DkaqM4-SC-tSxwwD"}
