globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/U3OT2DkaqM4-SC-tSxwwD/_buildManifest.js",
    "static/U3OT2DkaqM4-SC-tSxwwD/_ssgManifest.js",
    "static/U3OT2DkaqM4-SC-tSxwwD/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/041dqyk8t21v1.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0c7h~x4_chf35.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/turbopack-0xjp.lqz9gx3~.js"
  ]
};
